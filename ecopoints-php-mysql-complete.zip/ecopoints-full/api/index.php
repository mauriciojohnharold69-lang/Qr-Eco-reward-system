<?php
require __DIR__.'/../config.php';
try {
$action=$_GET['action']??'';
if ($action==='bootstrap') { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); out(['user'=>user(),'csrf'=>$_SESSION['csrf']]); }
if ($_SERVER['REQUEST_METHOD']!=='POST' && $action!=='data') out(['error'=>'Invalid request method.'],405);
if ($action==='data') {
 $u=require_user(); $uid=(int)$u['id'];
 $cats=db()->query('SELECT * FROM categories ORDER BY id')->fetchAll(); $rewards=db()->query('SELECT * FROM rewards WHERE active=1 ORDER BY points_cost')->fetchAll();
 $s=db()->prepare('SELECT s.id,s.weight,s.potential_points,s.image_path,s.status,s.created_at,c.name AS category,t.name AS station FROM submissions s JOIN categories c ON c.id=s.category_id JOIN stations t ON t.id=s.station_id WHERE s.user_id=? ORDER BY s.id DESC LIMIT 100'); $s->execute([$uid]); $sub=$s->fetchAll();
 $s=db()->prepare('SELECT r.id,r.points_spent,r.status,r.created_at,w.name AS reward FROM redemptions r JOIN rewards w ON w.id=r.reward_id WHERE r.user_id=? ORDER BY r.id DESC LIMIT 100'); $s->execute([$uid]); $red=$s->fetchAll();
 $s=db()->prepare("SELECT COALESCE(SUM(potential_points),0) FROM submissions WHERE user_id=? AND status='pending'"); $s->execute([$uid]); $pending=(int)$s->fetchColumn();
 $result=['user'=>$u,'categories'=>$cats,'rewards'=>$rewards,'submissions'=>$sub,'redemptions'=>$red,'balance'=>balance($uid),'pending'=>$pending];
 if ($u['role']==='admin') {
  $result['queue']=db()->query("SELECT s.id,s.weight,s.potential_points,s.image_path,s.created_at,c.name AS category,u.name AS submitter,t.name AS station FROM submissions s JOIN categories c ON c.id=s.category_id JOIN users u ON u.id=s.user_id JOIN stations t ON t.id=s.station_id WHERE s.status='pending' ORDER BY s.id ASC")->fetchAll();
  $result['claims']=db()->query("SELECT r.id,r.created_at,u.name AS submitter,w.name AS reward FROM redemptions r JOIN users u ON u.id=r.user_id JOIN rewards w ON w.id=r.reward_id WHERE r.status='requested' ORDER BY r.id ASC")->fetchAll();
 }
 out($result);
}
csrf(); $a=body();
if ($action==='register') {
 $name=trim((string)($a['name']??'')); $email=strtolower(trim((string)($a['email']??''))); $pw=(string)($a['password']??'');
 if (mb_strlen($name)<2 || mb_strlen($name)>120 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($pw)<8) out(['error'=>'Enter a name, valid email, and password of at least 8 characters.'],422);
 $s=db()->prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)'); try {$s->execute([$name,$email,password_hash($pw,PASSWORD_DEFAULT)]);} catch(PDOException $e) {if ($e->getCode()==='23000') out(['error'=>'Email already registered.'],409); throw $e;}
 session_regenerate_id(true); $_SESSION['uid']=(int)db()->lastInsertId(); out(['ok'=>true]);
}
if ($action==='login') {
 $s=db()->prepare('SELECT * FROM users WHERE email=?'); $s->execute([strtolower(trim((string)($a['email']??'')))]); $u=$s->fetch();
 if (!$u || !password_verify((string)($a['password']??''),$u['password_hash'])) out(['error'=>'Incorrect email or password.'],401);
 session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; out(['ok'=>true]);
}
if ($action==='logout') { $_SESSION=[]; session_regenerate_id(true); out(['ok'=>true]); }
$u=require_user(); $uid=(int)$u['id'];
if ($action==='submit') {
 $cid=filter_var($_POST['category_id']??null,FILTER_VALIDATE_INT); $weight=filter_var($_POST['weight']??null,FILTER_VALIDATE_FLOAT); $code=trim((string)($_POST['station_code']??''));
 if (!$cid || $weight===false || $weight<=0 || $weight>100 || !$code) out(['error'=>'Provide a category, station QR code and weight from 0.01 to 100 kg.'],422);
 $s=db()->prepare('SELECT points_per_kg FROM categories WHERE id=?'); $s->execute([$cid]); $rate=$s->fetchColumn();
 $s=db()->prepare('SELECT id FROM stations WHERE code=? AND active=1'); $s->execute([$code]); $station=$s->fetchColumn();
 if ($rate===false || !$station) out(['error'=>'Unknown category or QR station code.'],422);
 if (!isset($_FILES['image']) || $_FILES['image']['error']!==UPLOAD_ERR_OK || $_FILES['image']['size']>5*1024*1024) out(['error'=>'Upload an image smaller than 5 MB.'],422);
 $tmp=$_FILES['image']['tmp_name']; $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp); $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;
 if (!$ext || !getimagesize($tmp)) out(['error'=>'Only JPG, PNG, and WebP images are accepted.'],422);
 $filename=bin2hex(random_bytes(18)).'.'.$ext; $dest=__DIR__.'/../uploads/'.$filename;
 if (!move_uploaded_file($tmp,$dest)) out(['error'=>'Could not save image.'],500);
 $points=(int)round($weight*(int)$rate); if ($points<1) {unlink($dest);out(['error'=>'Weight is too small to earn points.'],422);}
 try {$s=db()->prepare('INSERT INTO submissions (user_id,category_id,station_id,weight,potential_points,image_path) VALUES (?,?,?,?,?,?)'); $s->execute([$uid,$cid,$station,$weight,$points,'uploads/'.$filename]);} catch(Throwable $e) {unlink($dest);throw $e;}
 out(['ok'=>true,'message'=>'Submitted for admin review.','points'=>$points]);
}
if ($action==='redeem') {
 $rid=filter_var($a['reward_id']??null,FILTER_VALIDATE_INT); if (!$rid) out(['error'=>'Choose a reward.'],422);
 $pdo=db();$pdo->beginTransaction();
 try {
  $s=$pdo->prepare('SELECT * FROM rewards WHERE id=? AND active=1 FOR UPDATE'); $s->execute([$rid]); $r=$s->fetch(); if (!$r || (int)$r['stock']<1) throw new RuntimeException('Reward is out of stock.');
  $s=$pdo->prepare('SELECT id FROM users WHERE id=? FOR UPDATE');$s->execute([$uid]);$s->fetch();
  if (balance($uid)<(int)$r['points_cost']) throw new RuntimeException('Not enough points yet.');
  $s=$pdo->prepare('UPDATE rewards SET stock=stock-1 WHERE id=?');$s->execute([$rid]);
  $s=$pdo->prepare('INSERT INTO redemptions (user_id,reward_id,points_spent) VALUES (?,?,?)');$s->execute([$uid,$rid,$r['points_cost']]);$redemptionId=(int)$pdo->lastInsertId();
  $s=$pdo->prepare("INSERT INTO point_transactions (user_id,amount,kind,redemption_id) VALUES (?,?,'redeemed',?)");$s->execute([$uid,-(int)$r['points_cost'],$redemptionId]);$pdo->commit();out(['ok'=>true,'message'=>'Reward requested. Visit your collection point when ready.']);
 } catch(Throwable $e) {$pdo->rollBack();if ($e instanceof RuntimeException) out(['error'=>$e->getMessage()],422);throw $e;}
}
if ($action==='review') {
 require_admin();$id=filter_var($a['id']??null,FILTER_VALIDATE_INT);$decision=$a['decision']??'';if (!$id || !in_array($decision,['approved','rejected'],true)) out(['error'=>'Invalid review.'],422);
 $pdo=db();$pdo->beginTransaction();try {
  $s=$pdo->prepare('SELECT * FROM submissions WHERE id=? FOR UPDATE');$s->execute([$id]);$sub=$s->fetch();if (!$sub || $sub['status']!=='pending') throw new RuntimeException('Submission already reviewed or not found.');
  $s=$pdo->prepare('UPDATE submissions SET status=?,reviewed_by=?,reviewed_at=NOW() WHERE id=?');$s->execute([$decision,$uid,$id]);
  if ($decision==='approved') {$s=$pdo->prepare("INSERT INTO point_transactions (user_id,amount,kind,submission_id) VALUES (?,?,'earned',?)");$s->execute([$sub['user_id'],$sub['potential_points'],$id]);}
  $pdo->commit();out(['ok'=>true]);
 }catch(Throwable $e){$pdo->rollBack();if ($e instanceof RuntimeException) out(['error'=>$e->getMessage()],422);throw $e;}
}
if ($action==='fulfill') {
 require_admin();$id=filter_var($a['id']??null,FILTER_VALIDATE_INT);if (!$id) out(['error'=>'Invalid claim.'],422);
 $s=db()->prepare("UPDATE redemptions SET status='fulfilled' WHERE id=? AND status='requested'");$s->execute([$id]);if (!$s->rowCount()) out(['error'=>'Claim not found or already fulfilled.'],422);out(['ok'=>true]);
}
out(['error'=>'Unknown action.'],404);
} catch(Throwable $e) {error_log((string)$e);out(['error'=>'Server error. Check PHP error logs and database configuration.'],500);}

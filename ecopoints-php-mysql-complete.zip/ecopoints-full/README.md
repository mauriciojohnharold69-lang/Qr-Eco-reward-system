# EcoPoints — PHP + MySQL + HTML/CSS/JavaScript

## XAMPP setup
1. Install XAMPP, start **Apache** and **MySQL**.
2. Extract the `ecopoints-full` folder into `C:\xampp\htdocs\` (Windows) or your XAMPP `htdocs` directory.
3. Visit `http://localhost/phpmyadmin` → **Import** → select `database.sql` → **Go**. This creates the `ecopoints` database, tables, waste categories, demo stations and rewards.
4. Edit `config.php` if your MySQL username/password differs from XAMPP's default `root` / blank. Set `BASE_URL` if you rename the folder.
5. Open `http://localhost/ecopoints-full/`. Register a user account.
6. To create an admin account, configure an Apache environment variable in `httpd.conf` (or the Apache virtual host) such as `SetEnv ECO_ADMIN_SETUP_SECRET "choose-a-long-random-secret"`, restart Apache, then visit `http://localhost/ecopoints-full/create_admin.php` and enter that secret, a new email, and a strong password. **Delete `create_admin.php` immediately afterward.** Do not leave the setup endpoint deployed.
7. Sign in with the administrator account to see the **Admin Panel**. Sign in as a regular user to upload a waste photo, scan a station QR code, and request rewards.

## Demo station QR codes
Generate QR codes containing the plain text `ECO-DEMO-01` and `ECO-SCHOOL-02`. These are pre-registered in the database. Alternatively, type the station code into the form. The scanner library loads from a public CDN; the device must be online to load it. Camera access requires HTTPS or localhost and permission. The upload input can open the phone camera.

## Workflow
- Waste points = round(weight in kg × category points/kg).
- New submissions start **pending** and count toward potential points, not available balance.
- Admin approves/rejects submissions. Approval creates a positive ledger transaction exactly once.
- Reward redemption locks the user's record and reward stock inside a database transaction, checks available balance, deducts points, and creates a claim.
- Admin marks a claim fulfilled after physically handing over the reward.
- Data persists in MySQL. Images are saved under `uploads/` with random filenames.

## OOP concepts
- `EcoAPI`: constructor, instance state and methods for API requests.
- `WasteCategory`: objects with `estimate()` method.
- `Reward`: reward objects with computed icon and availability.
- `EcoApp`: controller class with constructor, methods and arrays of category/reward objects.

## Important notes
- This is an educational prototype. Administrators must manually verify photos and weights; images are **not** automatically classified or validated as genuine.
- QR station codes are identifiers, not proof that a person is physically at a station. A production deployment should use authenticated collection staff, rotating signed QR tokens, and server-side verification.
- PHP sessions, CSRF protection, prepared statements, password hashing, MIME checking, random upload names and transaction-safe redemption are included.
- For deployment, use HTTPS, move secrets outside the web root, enable rate limiting, secure uploads with stronger web-server rules, use backups, and review privacy/security requirements.
- `uploads/.htaccess` blocks executable scripts on Apache. Keep Apache's `.htaccess` support enabled; test on your server.
- The app uses the external html5-qrcode library for QR scanning; other app code is plain HTML/CSS/JS/PHP/MySQL.

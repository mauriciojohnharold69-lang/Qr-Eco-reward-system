<?php
require __DIR__.'/config.php';
// ONE-TIME SETUP ONLY. Delete this file immediately after creating the administrator.
$message='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $secret=trim((string)($_POST['setup_secret']??''));
 $expected=getenv('ECO_ADMIN_SETUP_SECRET');
 if (!$expected || !hash_equals($expected,$secret)) $message='Set the ECO_ADMIN_SETUP_SECRET environment variable in Apache, then provide it here.';
 else {
  $name=trim((string)($_POST['name']??''));$email=strtolower(trim((string)($_POST['email']??'')));$password=(string)($_POST['password']??'');
  if (strlen($name)<2||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<12) $message='Provide valid name/email and a password of at least 12 characters.';
  else {try{$s=db()->prepare("INSERT INTO users(name,email,password_hash,role) VALUES (?,?,?,'admin')");$s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);$message='Admin created. DELETE create_admin.php NOW.';}catch(Throwable $e){$message='Could not create admin. Email may already be registered.';}}
 }
}
?><!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>One-time EcoPoints Admin Setup</title><link rel="stylesheet" href="assets/style.css"></head><body><main style="max-width:500px;margin:60px auto;padding:20px"><div class="panel"><h1>Create administrator</h1><p>Use once and then delete this file. Requires an Apache environment variable named ECO_ADMIN_SETUP_SECRET.</p><p><?=htmlspecialchars($message,ENT_QUOTES)?></p><form method="post"><label>Setup secret</label><input name="setup_secret" type="password" required><label>Name</label><input name="name" required><label>Email</label><input type="email" name="email" required><label>Password (12+ characters)</label><input type="password" name="password" minlength="12" required><button class="primary full">Create admin</button></form></div></main></body></html>

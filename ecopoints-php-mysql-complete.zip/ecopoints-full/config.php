<?php
declare(strict_types=1);
const DB_HOST='127.0.0.1';
const DB_NAME='ecopoints';
const DB_USER='root';
const DB_PASS='';
const BASE_URL='/ecopoints-full'; // Change if folder is renamed in htdocs
ini_set('display_errors','0');
session_start();
function db(): PDO { static $pdo=null; if (!$pdo) { $pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]); } return $pdo; }
function out($data,int $status=200): never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode($data,JSON_UNESCAPED_SLASHES); exit; }
function user(): ?array { if (empty($_SESSION['uid'])) return null; $s=db()->prepare('SELECT id,name,email,role FROM users WHERE id=?'); $s->execute([$_SESSION['uid']]); return $s->fetch() ?: null; }
function require_user(): array { $u=user(); if (!$u) out(['error'=>'Please log in.'],401); return $u; }
function require_admin(): array { $u=require_user(); if ($u['role']!=='admin') out(['error'=>'Administrator access required.'],403); return $u; }
function csrf(): void { if (!hash_equals($_SESSION['csrf']??'',$_SERVER['HTTP_X_CSRF_TOKEN']??'')) out(['error'=>'Invalid security token. Refresh the page.'],403); }
function body(): array { $a=json_decode(file_get_contents('php://input'),true); return is_array($a)?$a:[]; }
function balance(int $uid): int { $s=db()->prepare('SELECT COALESCE(SUM(amount),0) FROM point_transactions WHERE user_id=?'); $s->execute([$uid]); return (int)$s->fetchColumn(); }
